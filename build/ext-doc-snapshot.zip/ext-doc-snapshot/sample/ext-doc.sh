java -jar ../ext-doc.jar -p ext.xml -o ../output -t ../template/ext/template.xml -verbose
