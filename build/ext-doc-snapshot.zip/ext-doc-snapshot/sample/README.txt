1) Create here "ext" folder.
2) Put ExtJS source files inside "ext/source"
    ex.: sample/ext/source/core/Ext.js

Ext-doc will use ext.xml to find and process the source files.

